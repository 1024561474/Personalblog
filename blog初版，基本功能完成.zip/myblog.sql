/*
Navicat MySQL Data Transfer

Source Server         : root
Source Server Version : 50712
Source Host           : localhost:3306
Source Database       : myblog

Target Server Type    : MYSQL
Target Server Version : 50712
File Encoding         : 65001

Date: 2020-03-12 12:36:47
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for t_blog
-- ----------------------------
DROP TABLE IF EXISTS `t_blog`;
CREATE TABLE `t_blog` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `appreciation` bit(1) DEFAULT NULL,
  `commenttabled` bit(1) DEFAULT NULL,
  `content` text,
  `create_time` datetime DEFAULT NULL,
  `first_picture` varchar(255) DEFAULT NULL,
  `flag` varchar(255) DEFAULT NULL,
  `published` bit(1) DEFAULT NULL,
  `recommend` bit(1) DEFAULT NULL,
  `share_statement` bit(1) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `update_time` datetime DEFAULT NULL,
  `views` int(11) DEFAULT NULL,
  `type_id` bigint(20) DEFAULT NULL,
  `user_id` bigint(20) DEFAULT NULL,
  `commentabled` bit(1) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK292449gwg5yf7ocdlmswv9w4j` (`type_id`),
  KEY `FK8ky5rrsxh01nkhctmo7d48p82` (`user_id`),
  CONSTRAINT `FK292449gwg5yf7ocdlmswv9w4j` FOREIGN KEY (`type_id`) REFERENCES `t_type` (`id`),
  CONSTRAINT `FK8ky5rrsxh01nkhctmo7d48p82` FOREIGN KEY (`user_id`) REFERENCES `t_user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of t_blog
-- ----------------------------
INSERT INTO `t_blog` VALUES ('1', '', null, '11222333344445555', '2020-03-07 14:10:42', 'https://unsplash.it/100/100?image=1005', '', '', '', '', '1111', '2020-03-07 14:12:00', '4', '1', '1', '', '测试');
INSERT INTO `t_blog` VALUES ('2', '', null, '（观察者网讯）据韩联社3月8日报道，韩国中央防疫对策本部当天通报，截至当天0时，韩国较前一天新增367例感染新型冠状病毒确诊病例，累计确诊7134例。\r\n\r\n通报称，新增的367例中，来自大邱市和庆尚北道的共326例，分别为294例和32例。其余分别是首尔市12例、釜山市1例、大田市1例、蔚山市1例、世宗市1例、京畿道12例、江原道1例、忠清北道5例、忠清南道6例、庆尚南道1例。\r\n大邱和庆北的累计确诊病例为6459例，占整体的90.5%。其中大邱市5378例，庆尚北道1081例。京畿道累计确诊病例142例、首尔市120例、忠清南道98例、釜山市97例、庆尚南道83例、江原道27例、忠清北道25例、蔚山市24例、大田市19例、光州市13例、仁川市9例、全罗北道7例、全罗南道4例、世宗市3例。\r\n\r\n确诊病例中，女性4440例，占比62.2%。分年龄来看，20岁年龄段最多，占29.9%，达2133例。其后依次是50岁年龄段（1349例）、40岁年龄段（975例）、60岁年龄段（878例）。\r\n\r\n截至发稿，死亡病例累计50例。累计治愈并解除隔离病例共130例，较前日增加12例。共有超过18万人接受了新冠病毒检测，除确诊者之外有18.1384万人接受了检测，其中16.2008万人的检测结果呈阴性，其余1.9376万人的检测结果尚未出炉。\r\n\r\n据介绍，韩中央防疫对策本部2日起每天上午10时公布截至当天0时（前日24时）的疫情信息，下午5时公布截至当天下午4时的疫情信息。\r\n', '2020-03-08 14:31:22', 'https://unsplash.it/100/100?image=1005', '', '\0', '', '\0', '韩国最新病例', '2020-03-08 14:38:48', '17', '14', '1', '', '韩国新增367例，累计7134例\r\n');

-- ----------------------------
-- Table structure for t_blog_tags
-- ----------------------------
DROP TABLE IF EXISTS `t_blog_tags`;
CREATE TABLE `t_blog_tags` (
  `blogs_id` bigint(20) NOT NULL,
  `tags_id` bigint(20) NOT NULL,
  KEY `FK5feau0gb4lq47fdb03uboswm8` (`tags_id`),
  KEY `FKh4pacwjwofrugxa9hpwaxg6mr` (`blogs_id`),
  CONSTRAINT `FK5feau0gb4lq47fdb03uboswm8` FOREIGN KEY (`tags_id`) REFERENCES `t_tag` (`id`),
  CONSTRAINT `FKh4pacwjwofrugxa9hpwaxg6mr` FOREIGN KEY (`blogs_id`) REFERENCES `t_blog` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of t_blog_tags
-- ----------------------------
INSERT INTO `t_blog_tags` VALUES ('1', '1');
INSERT INTO `t_blog_tags` VALUES ('2', '3');

-- ----------------------------
-- Table structure for t_comment
-- ----------------------------
DROP TABLE IF EXISTS `t_comment`;
CREATE TABLE `t_comment` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `avatar` varchar(255) DEFAULT NULL,
  `comment` varchar(255) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `nickname` varchar(255) DEFAULT NULL,
  `blog_id` bigint(20) DEFAULT NULL,
  `parent_comment_id` bigint(20) DEFAULT NULL,
  `admin_comment` bit(1) NOT NULL,
  `content` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKke3uogd04j4jx316m1p51e05u` (`blog_id`),
  KEY `FK4jj284r3pb7japogvo6h72q95` (`parent_comment_id`),
  CONSTRAINT `FK4jj284r3pb7japogvo6h72q95` FOREIGN KEY (`parent_comment_id`) REFERENCES `t_comment` (`id`),
  CONSTRAINT `FKke3uogd04j4jx316m1p51e05u` FOREIGN KEY (`blog_id`) REFERENCES `t_blog` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of t_comment
-- ----------------------------
INSERT INTO `t_comment` VALUES ('1', '/images/avatar.png', null, '2020-03-08 14:36:25', '1024561747@qq.com', 'Mr·Poision', '1', null, '\0', '太狠了');

-- ----------------------------
-- Table structure for t_tag
-- ----------------------------
DROP TABLE IF EXISTS `t_tag`;
CREATE TABLE `t_tag` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of t_tag
-- ----------------------------
INSERT INTO `t_tag` VALUES ('1', '原创');
INSERT INTO `t_tag` VALUES ('2', 'CSS');
INSERT INTO `t_tag` VALUES ('3', '在线时事');

-- ----------------------------
-- Table structure for t_type
-- ----------------------------
DROP TABLE IF EXISTS `t_type`;
CREATE TABLE `t_type` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of t_type
-- ----------------------------
INSERT INTO `t_type` VALUES ('1', 'Java');
INSERT INTO `t_type` VALUES ('2', 'python');
INSERT INTO `t_type` VALUES ('3', 'windows10');
INSERT INTO `t_type` VALUES ('4', 'Linux');
INSERT INTO `t_type` VALUES ('5', 'windows Server 2008');
INSERT INTO `t_type` VALUES ('6', 'CentOS(Linux)');
INSERT INTO `t_type` VALUES ('9', 'JavaScript');
INSERT INTO `t_type` VALUES ('11', 'HTML5');
INSERT INTO `t_type` VALUES ('12', 'MyFaceBook');
INSERT INTO `t_type` VALUES ('13', 'CSS');
INSERT INTO `t_type` VALUES ('14', '事实新闻');

-- ----------------------------
-- Table structure for t_user
-- ----------------------------
DROP TABLE IF EXISTS `t_user`;
CREATE TABLE `t_user` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `avatar` varchar(255) DEFAULT NULL,
  `create_time` datetime DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `nickname` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `type` int(11) DEFAULT NULL,
  `update_time` datetime DEFAULT NULL,
  `username` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of t_user
-- ----------------------------
INSERT INTO `t_user` VALUES ('1', 'https://unsplash.it/100/100?image=1005', '2020-03-06 16:56:44', '1024561474@qq.com', 'Mr·Poision', 'f379eaf3c831b04de153469d1bec345e', '1', '2020-03-06 16:57:49', 'poision');
