package com.MrP.service;

import com.MrP.po.User;

public interface UserService {

    User checkUser(String username, String password);
}
